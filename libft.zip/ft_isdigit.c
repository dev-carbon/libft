#include "libft.h"

int	ft_isdigit(int c)
{
	return (c >= 49 && c <= 57);	
}